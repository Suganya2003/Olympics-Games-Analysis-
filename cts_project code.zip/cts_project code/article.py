import streamlit as st
import sqlite3
from datetime import datetime

# Set up the database connection
conn = sqlite3.connect('articles.db')
c = conn.cursor()

# Create a table to store blog articles if it doesn't exist
c.execute('''
CREATE TABLE IF NOT EXISTS articles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    content TEXT NOT NULL,
    author TEXT NOT NULL,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
)
''')
conn.commit()

# Function to get all articles from the database, with the latest ones first
def get_all_articles():
    c.execute('SELECT title, content, author, timestamp FROM articles ORDER BY timestamp DESC')
    return c.fetchall()


# Apply custom CSS for styling
st.markdown("""
    <style>
    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap');

    body {
        background-color: #E0F7FA; /* Light sky blue background */
        font-family: 'Poppins', sans-serif;
        color: #333333;
    }
    .header {
        background-color: #0288D1; /* Darker sky blue */
        padding: 40px 20px;
        text-align: center;
        color: #ffffff;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        border-radius: 10px;
        margin-bottom: 40px;
    }
    .header h1 {
        font-size: 50px;
        margin: 0;
        font-weight: 700;
    }
    .header h2 {
        font-size: 26px;
        margin: 10px 0 0;
        font-weight: 400;
    }
    .article-input {
        background-color: #ffffff;
        padding: 30px;
        margin-bottom: 20px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        border-radius: 10px;
    }
    .article-input label {
        font-size: 20px;
        color: #333333;
        margin-bottom: 10px;
    }
    .article-list {
        background-color: #ffffff;
        padding: 30px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        border-radius: 10px;
    }
    .article-list h3 {
        font-size: 28px;
        color: #0288D1; /* Darker sky blue */
    }
    .article {
        margin-bottom: 20px;
        padding: 10px;
        background-color: #000000;
        border-radius: 10px;
    }
    .article p {
        margin: 5px 0;
        font-size: 18px;
    }
    .footer {
        text-align: center;
        color: #0288D1; /* Darker sky blue */
        font-size: 18px;
        padding: 20px 0;
        margin-top: 40px;
        border-top: 1px solid #dddddd;
    }
    </style>
""", unsafe_allow_html=True)

# Header
st.markdown("""
    <div class="header">
        <h1>Articles</h1>
        <h2>Read and Share Knowledge</h2>
    </div>
""", unsafe_allow_html=True)

# Display all articles with the latest ones at the top
st.subheader("Latest Articles")

articles = get_all_articles()

for article in articles:
    with st.expander(article[0][0:20]+"...   - "+article[2]):
        st.markdown(f"""
            <div class="article">
                <h3>{article[0]}</h3>
                <p>{article[1]}</p>
                <small>Written by {article[2]} on {article[3]}</small>
            </div>
        """, unsafe_allow_html=True)

st.markdown("</div>", unsafe_allow_html=True)

# Footer with a quote
st.markdown("""
    <div class="footer">
        "An investment in knowledge pays the best interest." - Benjamin Franklin
    </div>
""", unsafe_allow_html=True)

# Close the database connection
conn.close()
