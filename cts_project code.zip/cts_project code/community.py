import streamlit as st
import sqlite3
from datetime import datetime

# Set up the database connection
conn = sqlite3.connect('community_chat.db')
c = conn.cursor()

# Create a table to store chat messages if it doesn't exist
c.execute('''
CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL,
    message TEXT NOT NULL,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
)
''')
conn.commit()

# Function to add a new message to the database
def add_message(username, message):
    c.execute('INSERT INTO messages (username, message) VALUES (?, ?)', (username, message))
    conn.commit()

# Function to get all messages from the database, with latest messages first
def get_all_messages():
    c.execute('SELECT username, message, timestamp FROM messages ORDER BY timestamp DESC')
    return c.fetchall()


# Header
st.markdown("""
    <div class="header">
        <h1>Community Chat</h1>
        <h2>Connect with Others and Share Your Thoughts</h2>
    </div>
""", unsafe_allow_html=True)

# Chat input section
st.subheader("Join the Conversation")
username = st.text_input("Enter your name", "")
message = st.text_area("Type your message here...")

if st.button("Send Message"):
    if username and message:
        add_message(username, message)
        st.success("Message sent!")
    else:
        st.error("Please enter both a name and a message.")

st.markdown("---")

# Display all messages with the latest ones at the top
st.subheader("Chat History")

messages = get_all_messages()

for msg in messages:
    st.markdown(f"**{msg[0]}** at {msg[2]}:")
    st.markdown(f"{msg[1]}")
    st.markdown("---")

# Close the database connection
conn.close()
