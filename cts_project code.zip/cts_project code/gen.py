from langchain_groq import ChatGroq

import streamlit as st
#import mysql.connector
import requests

connection=st.connection('mysql',type='sql')

# Connect to the MySQL database
'''conn = mysql.connector.connect(
    host="localhost", 
    user="root", 
    password="Jas_09_12", 
    database="sys"
)
cursor = conn.cursor()'''

# Streamlit UI for input
st.title("Patient Information Retrieval")
patient_id = st.text_input("Enter Patient ID:")

# Function to query the database for patient details
def get_patient_details(patient_id):
    s_query = f"SELECT * FROM patientdata WHERE patient_id = {patient_id}"  # Column to be matched is 'patient_id'
    return connection.query(s_query)

# Function to generate a detailed report using Groq's LLM model
def generate_report_groq(patient_details):
    llm = ChatGroq(
    temperature=0, 
    groq_api_key='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', 
    model_name="llama-3.1-70b-versatile"
    )

    prompt = f"Generate a detailed report for the following patient details: {patient_details}"
    return llm.invoke(prompt).content

# Main logic to handle patient_id input
if patient_id:
    details = get_patient_details(patient_id)
    if not details.empty:
        # Generate and display the report
        report = generate_report_groq(details)
        st.subheader("Patient Report:")
        st.write(report)
    else:
        st.error("Patient ID not found in the database.")