import streamlit as st
import pandas as pd
import sql
from sqlalchemy import text

#connection = sql.create_connection("localhost", "root", "Jas_09_12", "sys")
connection=st.connection('mysql',type='sql')

# Apply custom CSS to style the page
st.markdown("""
    <style>
    /* Gradient background for the header */
    .stTitle {
        background: linear-gradient(to right, #87CEEB, #4682B4, #000080);
        color: white;
        padding: 20px;
        border-radius: 10px;
        text-align: center;
        font-size: 2.5em;
        font-weight: bold;
    }
q2g
    /* Full-length divider */
    .stDivider {
        margin: 20px 0;
        height: 3px;
        background: linear-gradient(to right, #87CEEB, #4682B4, #000080);
        border: none;
    }

    /* Style for content area to fit the page with some padding */
    .stApp {
        padding: 0;
        margin: 0;
        width: 100%;
        max-width: 100%;
    }
    
    .main .block-container {
        padding-left: 20px;
        padding-right: 20px;
        margin: 0 auto;
        max-width: 90%;
        width: 90%;
    }
    
    .css-18e3th9 {
        flex-grow: 1;
        padding-left: 20px;
        padding-right: 20px;
        padding-top: 10px;
        width: 95%;
        max-width: 95%;
    }

    /* Button styling */
    .stButton>button {
        width: 100%;
        padding: 10px 20px;
        background-color: #87CEEB;
        background-image: linear-gradient(to right, #87CEEB, #4682B4, #000080);
        color: white !important;
        font-size: 1.2em;
        font-weight: bold;
        border-radius: 10px;
        border: none;
        cursor: pointer;
        transition: background-color 0.3s ease;
    }
    
    .stButton>button:hover {
        background-color: #4682B4;
        background-image: linear-gradient(to right, #4682B4, #000080);
        color: white !important;
    }

    .stButton>button:active {
        background-color: #000080;
        background-image: linear-gradient(to right, #000080, #4682B4);
        color: white !important;
    }

    /* Input box styling */
    .stTextInput>div>div>input {
        font-size: 1.2em;
        padding: 10px;
        border-radius: 8px;
        border: 2px solid #4682B4;
    }

    /* Style for the data editor */
    .stDataFrame {
        border-radius: 10px;
        border: 2px solid #4682B4;
    }
    </style>
    """, unsafe_allow_html=True)

# Header
st.markdown("<h1 class='stTitle'>Patient Record</h1>", unsafe_allow_html=True)

# Divider
st.markdown("<hr class='stDivider'>", unsafe_allow_html=True)

#data = pd.read_sql("select patient_id,disch_disp,LOS,ASA_Rating from patientdata limit 1000",connection)
data=connection.query("select patient_id,disch_disp,LOS,ASA_Rating from patientdata limit 1000",ttl=700)

# Initialize session state for DataFrame if it doesn't exist
if 'df1' not in st.session_state:
    st.session_state.df1 = data

# Update Section
st.subheader("Update Patient Record")
print(st.session_state.df1)
# Input for patient_id
patient_id = st.text_input("Enter Patient ID to Update")

if patient_id:
    # Filter the DataFrame to get the specific patient's row
    patient_row = st.session_state.df1[st.session_state.df1['patient_id'] == int(patient_id)]
    
    if not patient_row.empty:
        # Display editable table for the specific patient
        edited_patient_row = st.data_editor(patient_row, key="update_editor")
        # Update Button
        if st.button("Update Record", key="update_button"):
            st.session_state.df1.update(edited_patient_row)
            u_query=f"update patientdata set disch_disp='{edited_patient_row["disch_disp"].values[0]}',LOS='{float(edited_patient_row["LOS"].values)}',ASA_Rating='{edited_patient_row["ASA_Rating"].values[0]}' where patient_id='{patient_id}'"
            with connection.session as session:
                session.execute(text(u_query))
                session.commit()
            
            st.write("Patient record updated successfully!")
            st.dataframe(st.session_state.df1)
    else:
        st.write("No patient found with the given ID.")