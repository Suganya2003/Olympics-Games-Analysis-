import streamlit as st
import folium
from streamlit_folium import st_folium


article = st.Page("patient/article.py", title="Article",default=True)
community = st.Page("patient/community.py", title="Community",default=True)

# Apply custom CSS for styling
st.markdown("""
    <style>
    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap');

    body {
        background: linear-gradient(135deg, #ffb6c1, #add8e6); /* Light pink to light blue */
        font-family: 'Poppins', sans-serif;
        color: #333333;
    }
    .header {
        background: linear-gradient(90deg, #ff69b4, #87ceeb); /* Hot pink to sky blue */
        padding: 50px 20px;
        text-align: center;
        color: #ffffff;
    }
    .header h1 {
        font-size: 60px;
        margin: 0;
    }
    .header h2 {
        font-size: 30px;
        margin: 10px 0 0;
    }
    .intro {
        background-color: #ffffff;
        padding: 40px 20px;
        color: #333333;
        text-align: center;
    }
    .intro h3 {
        font-size: 32px;
        margin: 0;
        color: #ff69b4; /* Hot pink */
    }
    .intro p {
        font-size: 20px;
        margin: 20px 0;
        line-height: 1.6;
    }
    .features {
        padding: 40px 20px 0;
        background-color: #333333;
    }
    .features h2 {
        text-align: center;
        color: #ff1493; /* Deep pink */
        font-size: 36px;
        margin-bottom: 20px;
    }
    .features ul {
        list-style-type: none;
        padding: 0;
    }
    .features li {
        font-size: 20px;
        color: #ffffff;
        margin-bottom: 15px;
    }
    .cta-button {
        display: block;
        width: 240px;
        margin: 50px auto;
        text-align: center;
        padding: 20px 30px;
        font-size: 22px;
        color: #ffffff;
        background-color: #ff69b4; /* Hot pink */
        border-radius: 10px;
        text-decoration: none;
        font-weight: 700;
    }
    .cta-button:hover {
        background-color: #ff1493; /* Deep pink */
    }
    .map-container {
        display: flex;
        margin: 20px 0;
    }
    .map {
        flex: 70%; 
    }
    .map-content {
        flex: 30%;
        padding: 20px;
        background-color: #A2F;
        color: #ffffff;
        border-radius: 10px;
        margin-left: 20px;
    }
    .footer {
        text-align: center;
        color: #ff69b4; /* Hot pink */
        font-size: 18px;
        padding: 40px 0; /* Increased padding for spacing */
        border-top: 1px solid #ffffff;
        margin-top: 50px; /* Add margin-top to separate from content above */
    }
    .community-article-container {
        display: flex;
        justify-content: space-around;
        margin-top: 50px;
    }
    .community-article-box {
        background-color: #ffffff;
        padding: 40px;
        border-radius: 10px;
        width: 45%;
        box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
        text-align: center;
    }
    .community-article-box h3 {
        font-size: 28px;
        color: #00aced; /* Light blue */
        margin-bottom: 20px;
    }
    .community-article-box p {
        font-size: 18px;
        color: #333333;
    }
    </style>
""", unsafe_allow_html=True)

# Header section
st.markdown("""
    <div class="header">
        <h1>Welcome to Patient Care Analysis Dashboard</h1>
        <h2>Revolutionizing Healthcare with Real-Time Data</h2>
    </div>
""", unsafe_allow_html=True)

# Introductory section
st.markdown("""
    <div class="intro">
        <h3>Enhance Patient Care and Optimize Resources</h3>
        <p>
            Discover how our Patient Care Analysis Dashboard empowers healthcare professionals with actionable insights. 
            Monitor patient data, track disease trends, and optimize hospital resources to improve patient outcomes and 
            operational efficiency. Dive into a world of data-driven decision-making with a user-friendly interface and interactive features.
        </p>
    </div>
""", unsafe_allow_html=True)

# Features section
st.markdown("""
    <div class="features">
        <h2>Key Features</h2>
        <ul>
            <li>Real-Time Patient Data Monitoring</li>
            <li>Customizable Visualizations and Reports</li>
            <li>Predictive Analytics for Disease Management</li>
            <li>Efficient Resource Allocation Tools</li>
            <li>Interactive Dashboards and User-Friendly Interface</li>
        </ul>
    </div>
""", unsafe_allow_html=True)

# Interactive map section with content on the right
st.markdown("""
    <div class="map-container">
        <div class="map">
""", unsafe_allow_html=True)

# Create a map
map = folium.Map(location=[20.5937, 78.9629], zoom_start=5)  # Centered on India

# Add some sample markers (replace with actual data as needed)
folium.Marker(location=[28.6139, 77.2090], popup='Delhi Hospital').add_to(map)
folium.Marker(location=[19.0760, 72.8777], popup='Mumbai Hospital').add_to(map)
folium.Marker(location=[13.0827, 80.2707], popup='Chennai Hospital, Tamil Nadu').add_to(map)  # Tamil Nadu

# Display map in Streamlit
st_folium(map, width=800)

st.markdown("""
    </div>
        <div class="map-content">
            <h3>Hospital Information</h3>
            <p>Click on the markers on the map to view details about each hospital.</p>
            <ul>
                <li>Location: View the exact coordinates of hospitals.</li>
                <li>Services: Check available services at each location.</li>
                <li>Contact: Get in touch with the hospital for appointments.</li>
            </ul>
        </div>
    </div>
""", unsafe_allow_html=True)

# Community and Article sections side by side
st.markdown("""
    <div class="community-article-container">
        <div class="community-article-box">
            <h3>Community</h3>
            <p>Join discussions, ask questions, and connect with other patients and healthcare professionals.</p>
        </div>
        <div class="community-article-box">
            <h3>Article</h3>
            <p>Read useful articles and resources curated for patients, covering various healthcare topics.</p>
        </div>
    </div>
""", unsafe_allow_html=True)
cols=st.columns(2)
with cols[0]:
    subcols=st.columns(3)
    with subcols[1]:
        st.page_link(article)

with cols[1]:
    subcols=st.columns(3)
    with subcols[1]:
        st.page_link(community)

# Footer with medical quote
st.markdown("""
    <div class="footer">
        "The art of medicine consists of amusing the patient while nature cures the disease." - Voltaire
    </div>
""", unsafe_allow_html=True)
